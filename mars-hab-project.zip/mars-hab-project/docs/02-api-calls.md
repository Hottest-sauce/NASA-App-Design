# 2. Using API calls to grab data

An API is a URL that returns data instead of a web page. Open this in a browser tab:

```
https://api.nasa.gov/DONKI/FLR?startDate=2026-01-01&endDate=2026-01-07&api_key=DEMO_KEY
```

You will see JSON (the same shape as a Python dict/list).

## The code: `js/api.js`

```js
const response = await fetch(url);          // send the request, wait for headers
if (!response.ok) throw new Error(...);     // 404, 429 (rate limit), 500...
const flares = JSON.parse(await response.text());
```

### async / await in 30 seconds

- `fetch` returns a **Promise**: "the answer comes later".
- `await` pauses only this function until it arrives. The page stays responsive (buttons still click).
- A function that uses `await` must be marked `async`, and callers must `await` it too. See `solar.js`:

```js
export async function start(h) {
  const activity = await getSolarActivity();   // pause here
  ...
}
```

## Always plan for failure

Networks fail. `api.js` wraps the call in `try/catch` and falls back to `data/sample-donki.json`. The solar panel shows which source was used. Try it: turn off your Wi-Fi and open the Solar Window.

## From raw data to gameplay

`stormRisk(flares)` counts M-class and X-class flares and returns 0..1. `solar.js` turns that into a storm window. This three-step pattern is the one to copy:

1. **Fetch** raw data (`getSolarActivity`)
2. **Reduce** it to one game number (`stormRisk`)
3. **Use** that number in the game (`stormLen = 2 + 4 * risk`)

## Gotchas

- **API keys:** `DEMO_KEY` is shared and rate-limited. Get a free key at <https://api.nasa.gov>. Never commit a private key to a public repo.
- **CORS:** browsers only allow calls to servers that permit it. NASA's does. If an API does not, you need a small server to proxy it.
- **Need the sun's real direction?** DONKI has events, not sun angles. Look at the InSight weather docs and NASA's other datasets, or compute it from latitude, day and time. Swap it in at `sunAngle()` in `solar.js`.
- **Debugging:** F12 > Network tab shows each request, status code and response.
