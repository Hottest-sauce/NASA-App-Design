# 1. Putting visuals in a GUI

A web "GUI" is a stack of layers. Our scene has four:

```
 z-order (back to front)
 ┌──────────────────────────────┐
 │ 4. dialogue / toast / modal  │  text boxes (ui.js)
 │ 3. hotspots (buttons)        │  built from rooms.json (render.js)
 │ 2. (nothing: free layer)     │
 │ 1. <img id="room-bg">        │  the room picture
 └──────────────────────────────┘
```

Open `index.html` and find `#scene`. Its children are the layers.

## Idea A: position with percentages

`css/style.css` makes `#scene` `position: relative`, and hotspots `position: absolute`.
A hotspot with `x:6, y:38, w:20, h:36` in `rooms.json` becomes `left:6%; top:38%; width:20%; height:36%` (`render.js`).
Because they are percentages, everything scales when the window resizes. Press **D** in the game to see the boxes.

## Idea B: pictures are just `<img>` tags

`render.js` creates an `<img>` per hotspot and sets `img.src` to the path in the JSON. That is the whole trick. Drawing art for a game is a matter of putting the right file in the right slot.

Fallback: if an image fails to load, `img.onerror` swaps in the emoji. You never see a broken-image icon.

## Idea C: two ways to draw dynamic things

| | `<canvas>` (`games/solar.js`) | DOM + CSS (`games/datalink.js`) |
|---|---|---|
| Like | pygame, Java Graphics2D | normal widgets |
| You do | clear + redraw every frame | change style of existing elements |
| Rotate by | trig on line endpoints | `el.style.transform = 'rotate(45deg)'` |
| Best for | many shapes, particles, charts | few objects, real image files |

### Rotating something (the core prototype requirement)

Read `datalink.js`:

```js
const turn = `rotate(${angle - 90}deg)`;
dish.style.transform = turn;
```

Read `solar.js` `draw()` for the canvas version. The panel is a line through its center, perpendicular to the direction it faces.

### Scaling points by alignment

```js
export const alignment = (sun, panel) => Math.max(0, Math.cos(((sun - panel) * Math.PI) / 180));
```

`cos` is a smooth 1 → 0 curve: perfect aim = 1, 45° off ≈ 0.71, 90° off = 0. Multiply by anything to make a score. For a harsher curve, square it: `alignment ** 2`.

## The game loop

Games need "do something about 60 times a second". `ui.js` `runLoop()` wraps `requestAnimationFrame`. Each frame: read input → update numbers → redraw. Same pattern as a `while(running)` loop in C++ game tutorials, but the browser calls you instead of you blocking.
