# 3. Hot swapping images and interactables

"Hot swap" = change what is on screen without editing game code or restarting. The project does this with one rule:

> **Code reads content from data. It never contains it.**

## Swap an image

1. Put your PNG in `assets/icons/` (e.g. `generator.png`).
2. In `data/rooms.json`, change the hotspot:
   ```json
   "icon": "assets/icons/generator.png"
   ```
3. Save. Live Server refreshes. Or press **R** in the game to reload data and images **without losing your resources**.

Same for backgrounds: edit `"background"` for the room.

Asset tips:

| Thing | Format | Size |
|---|---|---|
| Room background | PNG/JPG/SVG, 16:9 | 1600×900 |
| Hotspot icon | PNG with transparent background, or SVG | 256×256 |

You can also just overwrite the file with the same name. Pressing **R** adds `?v=<time>` to bypass the browser cache (`render.js`, `bumpCache`).

## Move or resize an interactable

Edit `x, y, w, h` in `rooms.json` (percent of the room). Press **D** to see the boxes. Press **R** to apply.

## Change what an interactable does

The `"action"` field is a key into the registry in `js/actions.js`:

```js
export const actions = {
  'modal': simpleModal,
  'minigame:solar': (h) => solar.start(h),
  'minigame:datalink': (h) => datalink.start(h),
};
```

Change the generator from a basic pop-up to the solar game by changing one word in JSON:

```json
"action": "minigame:solar"
```

## Add a brand-new mini-game

1. Create `js/games/generator.js` that exports `start(hotspot)` (copy `datalink.js` as a template).
2. In `actions.js`: `import * as generator from './games/generator.js';` and add `'minigame:generator': (h) => generator.start(h),`.
3. In `rooms.json`, set a hotspot's `"action": "minigame:generator"`.

Nothing else changes: not the renderer, not the HUD, not other rooms.

## Add a new room

Copy a room object in `rooms.json`, give it a new `id`, `name`, `background` and hotspots. The arrow buttons pick it up automatically (they loop over the array).

## Why this works (design lesson)

| Without hot swap | With it |
|---|---|
| Artist waits for a programmer to edit code | Artist edits JSON/PNG |
| One giant file | Small files with one job each |
| Adding a room = new code | Adding a room = new data |

This is called **data-driven design**. Game engines (Unity, Godot, Unreal) are built on the same idea.
