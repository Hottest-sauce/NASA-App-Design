# Hold the Fort: Mars Hab (learning project)

A tiny resource-management game built to teach three things:

1. **Visuals in a GUI**: layering pictures, buttons, and drawings.
2. **API calls**: fetching live NASA data and using it in gameplay.
3. **Hot swapping**: changing art and interactables by editing files, not code.

No frameworks, no build step. Just HTML, CSS and JavaScript.

## Run it (2 minutes)

1. Open this folder in VS Code (`File > Open Folder`).
2. Install the recommended extension **Live Server** (VS Code will prompt you).
3. Right-click `index.html` and choose **Open with Live Server**.

No VS Code extension? In a terminal inside this folder run `python -m http.server 8000`, then open <http://localhost:8000>.

> Double-clicking `index.html` will NOT work. Browsers block loading `data/rooms.json` from a plain file. A tiny local server fixes that.

## Project map (read in this order)

```
index.html          the page skeleton (layers: background, hotspots, dialogue)
css/style.css       how things look and where they sit
data/rooms.json     THE CONTENT: rooms, images, hotspot positions, actions   <- you edit this
data/sample-donki.json  offline fallback for the API
assets/rooms/       background pictures (placeholder SVGs)
assets/icons/       hotspot pictures (placeholder SVGs)
js/main.js          entry point, wires everything, keyboard + reload
js/state.js         game numbers (resources) + "tell me when these change"
js/render.js        data -> pixels (builds hotspots from rooms.json)
js/actions.js       maps "action" names in rooms.json to functions
js/api.js           fetch() to NASA DONKI + fallback
js/ui.js            dialogue, toast, modal, game loop helper
js/games/solar.js   canvas mini-game: rotate a panel, alignment scoring, API storm risk
js/games/datalink.js  DOM mini-game: rotate an <img>, satellites on an arc, overlap bonus
docs/               one guide per topic below
```

## Learning path

| Goal | Read | Then try |
|---|---|---|
| 1. Visuals | [docs/01-visuals.md](docs/01-visuals.md) | Exercise 1 |
| 2. API calls | [docs/02-api-calls.md](docs/02-api-calls.md) | Exercise 2 |
| 3. Hot swap | [docs/03-hot-swap.md](docs/03-hot-swap.md) | Exercise 3 |

## Cheat sheet for C++ / Java / Python folks

| Idea | JavaScript | Python | Java |
|---|---|---|---|
| Variable | `let x = 1; const y = 2;` | `x = 1` | `int x = 1; final int y = 2;` |
| Function | `function f(a){}` or `(a) => a*2` | `def f(a):` / `lambda` | method / lambda |
| List | `[1,2,3]` + `.map .filter` | `list` + comprehension | `List` + streams |
| Dict / object | `{name:'x'}` | `dict` | `Map` / class |
| Loop over list | `for (const h of list)` | `for h in list:` | `for (Hotspot h : list)` |
| Import | `import {a} from './a.js'` | `from a import a` | `import pkg.A;` |
| Wait for slow work | `await fetch(url)` | `requests.get(url)` | `client.send(...)` |
| Print debug | `console.log(x)` | `print(x)` | `System.out.println(x)` |

Debug tip: press **F12** in the browser, open the **Console** tab, and watch for red errors.

## Exercises

1. **Visuals:** In `css/style.css`, change `#hotspots`' child `.hotspot` hover color. Then in `datalink.js` change the 🛰️ emoji to `📡` and see it update.
2. **API:** In `api.js`, change `getSolarActivity(7)` to look back 30 days (edit the call in `solar.js`). Open the Network tab (F12) and find the request.
3. **Hot swap:** Add a new hotspot to `rooms.json` (copy one, give it a new `id`, `x`, `y`). Press **R** in the game. No restart.

## Next steps (ideas)

- Use real sun direction data in `sunAngle()` (see the comment in `solar.js`).
- Add a `"minigame:generator"` action and a new file in `js/games/`.
- Replace placeholder SVGs with your own transparent PNGs.
