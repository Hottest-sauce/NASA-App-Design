// UI HELPERS: dialogue box, toast, modal window, and a tiny game loop.
export const $ = (selector) => document.querySelector(selector);

export function say(text, who = 'You') {
  $('#dialogue').innerHTML = `<b>${who}</b><br>${text}`;
}

let toastTimer;
export function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.style.opacity = 1;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.style.opacity = 0), 1600);
}

// ---- modal (pop-up window) ----
let onCloseCallback = null;
export const isModalOpen = () => !$('#modal').hidden;

// Puts html inside a panel, shows it, and returns the panel element so callers can find buttons in it.
export function openModal(html, onClose) {
  const modal = $('#modal');
  modal.innerHTML = `<div class="panel">${html}</div>`;
  modal.hidden = false;
  onCloseCallback = onClose || null;
  return modal.firstElementChild;
}
export function closeModal() {
  if (!isModalOpen()) return;
  $('#modal').hidden = true;
  if (onCloseCallback) onCloseCallback();   // lets a game stop its loop
  onCloseCallback = null;
}

// ---- game loop ----
// Calls tick(secondsElapsed, dt) about 60 times a second until `seconds` pass, then calls end().
// requestAnimationFrame = "call me right before the next screen refresh".
// Returns a stop() function. (Think of it as a while-loop that lets the browser breathe between turns.)
export function runLoop(seconds, tick, end) {
  let t = 0, last = performance.now(), alive = true;
  function frame(now) {
    if (!alive) return;
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now; t += dt;
    tick(t, dt);
    if (t >= seconds) { alive = false; end(); return; }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  return () => { alive = false; };
}
