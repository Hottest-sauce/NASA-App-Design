// DATALINK GAME. Teaches:
//   1. Building a game from normal page elements (not canvas): <img> + CSS transform
//   2. Rotating an IMAGE with style.transform = 'rotate(…deg)'
//   3. Moving things along an arc with sin/cos
//   4. Overlap bonus logic
import { openModal, closeModal, toast, runLoop } from '../ui.js';
import { applyEffects, resources } from '../state.js';

const DURATION = 20;
// Each satellite: [starting angle, speed in degrees/second]. Negative speed = moves the other way.
const SATS = [[0, 9], [60, 6], [130, -7]];
const satAngle = ([start, speed], t) => (((start + speed * t) % 180) + 180) % 180;   // wrap into 0..180

export function start(h) {
  let stop = () => {};
  const panel = openModal(`
    <h2>${h.title}</h2>
    <p>Dad-phone: Point the dish at a satellite to send our data home. Two satellites in the beam means a stronger signal!</p>
    <div class="sky">
      ${SATS.map(() => '<span class="sat">🛰️</span>').join('')}
      <div id="beam"></div>
      <img id="dish" src="assets/icons/uplink.svg" alt="dish">   <!-- swap this file to change the dish art -->
    </div>
    <label>Dish angle <b id="av">90</b>°<input id="sl" type="range" min="0" max="180" step="1" value="90"></label>
    <div class="stat" id="st"></div>
    <div class="row"><button id="x">Abort</button></div>`, () => stop());

  const sats = [...panel.querySelectorAll('.sat')];
  const beam = panel.querySelector('#beam'), dish = panel.querySelector('#dish');
  const slider = panel.querySelector('#sl');
  slider.oninput = () => (panel.querySelector('#av').textContent = slider.value);
  panel.querySelector('#x').onclick = closeModal;
  let sent = 0;

  stop = runLoop(DURATION,
    (t, dt) => {
      const angle = +slider.value, rad = Math.PI / 180;

      // 1. Move satellites (positions are % of the sky box, so it scales with screen size).
      const quality = SATS.map((s, i) => {
        const a = satAngle(s, t);
        sats[i].style.left = 50 - 42 * Math.cos(a * rad) + '%';
        sats[i].style.top = 92 - 80 * Math.sin(a * rad) + '%';
        return Math.max(0, 1 - Math.abs(a - angle) / 22);   // 1 = dead center, 0 = 22° or more away
      });

      // 2. Signal = best satellite, with a x1.3 bonus when two overlap in the beam.
      const inBeam = quality.filter((q) => q > 0.05).length;
      const signal = Math.min(1.3, Math.max(...quality) * (inBeam > 1 ? 1.3 : 1));

      // 3. ROTATE THE IMAGE: 90° means straight up, so we rotate by (angle - 90).
      const turn = `rotate(${angle - 90}deg)`;
      beam.style.transform = turn;
      dish.style.transform = turn;
      beam.style.background = `rgba(120,255,160,${Math.max(0.15, Math.min(1, signal))})`;

      // 4. Send data: 8 MB/s at full signal, but never more than what's queued.
      sent = Math.min(resources.queue.value, sent + signal * 8 * dt);
      panel.querySelector('#st').textContent =
        `Signal ${Math.round(signal * 100)}% · ${(signal * 8).toFixed(1)} MB/s · ${sent.toFixed(0)} MB sent · ${Math.ceil(DURATION - t)}s left`;
    },
    () => {
      const mb = Math.round(sent);
      applyEffects({ queue: -mb, sent: mb, power: -5 });
      toast(`Uploaded ${mb} MB to Earth`);
      closeModal();
    });
}
