// SOLAR ARRAY GAME. Teaches:
//   1. Drawing with <canvas> (like Java's Graphics2D or Python's pygame / turtle)
//   2. Rotating a shape from a slider value
//   3. Scoring based on alignment (trigonometry: cos)
//   4. Using API data to change gameplay (async/await)
import { openModal, closeModal, toast, runLoop, isModalOpen } from '../ui.js';
import { applyEffects } from '../state.js';
import { getSolarActivity, stormRisk } from '../api.js';

const DURATION = 20;   // seconds

// Fake sun path: degrees, 0 = east horizon, 90 = overhead, 180 = west horizon.
// SWAP-IN POINT: replace this one function with real sun-direction data later.
const sunAngle = (t) => 25 + t * 6;

// ALIGNMENT SCORE: 1.0 when the panel faces the sun, falling to 0 at 90 degrees off.
// cos(0°)=1, cos(45°)=0.71, cos(90°)=0. Negative values (panel facing away) are clamped to 0.
export const alignment = (sun, panel) => Math.max(0, Math.cos(((sun - panel) * Math.PI) / 180));

export async function start(h) {
  openModal(`<h2>${h.title}</h2><p>Contacting NASA…</p>`);
  const activity = await getSolarActivity();   // waits for the network
  if (!isModalOpen()) return;                  // player closed the window while we waited
  const risk = stormRisk(activity.flares);     // 0..1 from real flare data
  const stormStart = 8, stormLen = risk > 0 ? 2 + 4 * risk : 0;

  let stop = () => {};
  const panel = openModal(`
    <h2>${h.title}</h2>
    <p>Dad-phone: Solar panels make power from the sun, so line them up with it! Fold the array away in a storm.</p>
    <p class="stat">Flare data: ${activity.source} · storm risk ${Math.round(risk * 100)}%</p>
    <canvas width="480" height="230"></canvas>
    <label>Panel angle <b id="av">90</b>°<input id="sl" type="range" min="0" max="180" step="1" value="90"></label>
    <div class="stat" id="st"></div>
    <div class="row"><button id="tg">Fold array</button><button id="x">Abort</button></div>`,
    () => stop());

  const ctx = panel.querySelector('canvas').getContext('2d');
  const slider = panel.querySelector('#sl');
  slider.oninput = () => (panel.querySelector('#av').textContent = slider.value);
  let open = true, points = 0;
  panel.querySelector('#tg').onclick = (e) => { open = !open; e.target.textContent = open ? 'Fold array' : 'Open array'; };
  panel.querySelector('#x').onclick = closeModal;

  stop = runLoop(DURATION,
    (t, dt) => {                                       // runs ~60 times per second
      const sun = sunAngle(t), angle = +slider.value;
      const storm = t > stormStart && t < stormStart + stormLen;
      const a = open ? alignment(sun, angle) : 0;
      points += a * dt * 5;                            // up to 5 points/second at perfect alignment
      if (storm && open) points = Math.max(0, points - 10 * dt);   // storm damages an open array
      draw(ctx, sun, angle, open, a, storm);
      panel.querySelector('#st').textContent =
        `Sun ${Math.round(sun)}° · alignment ${Math.round(a * 100)}% · points ${Math.round(points)} · ${Math.ceil(DURATION - t)}s left`;
    },
    () => {                                            // runs once at the end
      const power = Math.round(points * 0.25);
      applyEffects({ power });
      toast(`Array harvested ${Math.round(points)} points: +${power} power`);
      closeModal();
    });
}

// DRAWING. Canvas works like a painter: set a color, then draw a shape. Nothing is remembered,
// so we clear and redraw everything every frame.
function draw(ctx, sun, angle, open, a, storm) {
  const rad = Math.PI / 180, cx = 240, cy = 205;
  const onArc = (deg, len) => [cx - len * Math.cos(deg * rad), cy - len * Math.sin(deg * rad)];
  ctx.clearRect(0, 0, 480, 230);
  ctx.fillStyle = '#4a2a1c'; ctx.fillRect(0, cy, 480, 25);              // ground

  const [sx, sy] = onArc(sun, 170);
  ctx.fillStyle = '#ffd24d'; ctx.beginPath(); ctx.arc(sx, sy, 14, 0, 7); ctx.fill();   // sun
  if (a > 0) {                                                           // sunbeam, brighter = better aligned
    ctx.strokeStyle = `rgba(255,210,77,${a})`; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(cx, cy - 6); ctx.stroke();
  }

  // ROTATING THE PANEL: a line through the center, perpendicular to the direction it faces.
  ctx.lineWidth = 9; ctx.strokeStyle = open ? '#6aa8ff' : '#556';
  ctx.beginPath();
  if (open) {
    const s = Math.sin(angle * rad), c = Math.cos(angle * rad);
    ctx.moveTo(cx - 45 * s, cy - 6 + 45 * c); ctx.lineTo(cx + 45 * s, cy - 6 - 45 * c);
  } else { ctx.moveTo(cx - 45, cy - 6); ctx.lineTo(cx + 45, cy - 6); }   // folded flat
  ctx.stroke();

  if (storm) {
    ctx.fillStyle = 'rgba(120,40,40,.35)'; ctx.fillRect(0, 0, 480, 230);
    ctx.fillStyle = '#ff9a8a'; ctx.font = '16px system-ui'; ctx.fillText('⚠ DUST STORM: fold the array!', 130, 28);
  }
}
