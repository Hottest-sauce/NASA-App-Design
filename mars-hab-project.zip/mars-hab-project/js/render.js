// RENDERING: turns data (rooms.json) into things on screen.
// The key idea: we never hard-code a picture or a button position here. We READ them from data.
import { resources } from './state.js';
import { runAction } from './actions.js';
import { $, say } from './ui.js';

// Cache-buster: browsers remember images. Adding ?v=12345 makes them think it's a new file.
let bust = Date.now();
export const bumpCache = () => { bust = Date.now(); };
const url = (path) => `${path}?v=${bust}`;

export function renderHud() {
  $('#hud').innerHTML = Object.values(resources).map((r) =>
    `<div class="res">${r.icon} ${r.name} <b>${Math.round(r.value)}</b>
     <i><span style="width:${(r.value / r.max) * 100}%"></span></i></div>`).join('')
    + '<button id="reload">🔄 Reload (R)</button>';
}

export function renderRoom(room, index, total) {
  $('#room-bg').src = url(room.background);                 // 1. swap the background picture
  $('#roomname').textContent = `${room.name} · room ${index + 1}/${total}`;

  const layer = $('#hotspots');
  layer.innerHTML = '';                                      // 2. clear old hotspots
  for (const h of room.hotspots) {                           // 3. build one button per hotspot (a for-loop over data)
    const el = document.createElement('button');
    el.className = 'hotspot';
    el.style.cssText = `left:${h.x}%;top:${h.y}%;width:${h.w}%;height:${h.h}%`;   // position in % of the stage

    const img = document.createElement('img');
    img.src = url(h.icon);
    img.alt = '';
    // If the image file is missing or broken, show the emoji instead of a broken-image icon.
    img.onerror = () => {
      const span = document.createElement('span');
      span.className = 'emoji';
      span.textContent = h.emoji || '❓';
      img.replaceWith(span);
    };

    const label = document.createElement('span');
    label.className = 'lb';
    label.textContent = h.label;

    el.append(img, label);
    el.onclick = () => runAction(h);                         // click -> look up action in actions.js
    el.onmouseenter = () => say(h.line || h.label);
    layer.append(el);
  }
  say(`You step into the ${room.name}.`);
}
