// ENTRY POINT: wires everything together. Read this file first.
import { subscribe } from './state.js';
import { renderHud, renderRoom, bumpCache } from './render.js';
import { $, say, toast, closeModal, isModalOpen } from './ui.js';

let rooms = [];
let current = 0;

// Fetch the room list from a JSON file. ?t=... stops the browser from reusing an old copy.
async function loadRooms() {
  const response = await fetch(`data/rooms.json?t=${Date.now()}`);
  rooms = (await response.json()).rooms;
}

function show(i) {
  current = (i + rooms.length) % rooms.length;   // wrap around
  renderRoom(rooms[current], current, rooms.length);
}

// HOT RELOAD: re-read rooms.json and re-fetch images WITHOUT restarting the game (resources are kept).
async function hotReload() {
  bumpCache();
  await loadRooms();
  show(Math.min(current, rooms.length - 1));
  toast('Reloaded rooms.json + images');
}

async function init() {
  subscribe(renderHud);          // whenever state changes, redraw the HUD
  renderHud();
  // The HUD is rebuilt often, so listen on the parent that never changes ("event delegation").
  $('#hud').addEventListener('click', (e) => { if (e.target.id === 'reload') hotReload(); });
  $('#prev').onclick = () => show(current - 1);
  $('#next').onclick = () => show(current + 1);

  addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
    if (isModalOpen()) return;                   // ignore other keys while a pop-up is open
    if (e.key === 'ArrowLeft') show(current - 1);
    if (e.key === 'ArrowRight') show(current + 1);
    if (e.key.toLowerCase() === 'r') hotReload();
    if (e.key.toLowerCase() === 'd') document.body.classList.toggle('debug');
  });

  try {
    await loadRooms();
    show(0);
    say('Sol 1. Mom and Dad are away. Keep the base running and send data home.', 'Narrator');
  } catch (err) {
    document.body.insertAdjacentHTML('afterbegin',
      '<p class="err">Could not load data/rooms.json. Open this folder with the Live Server extension (see README).</p>');
    console.error(err);
  }
}
init();
