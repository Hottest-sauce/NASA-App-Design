// API CALLS: fetching live data from the internet.
//
//   Python:  requests.get(url).json()
//   Java:    HttpClient.send(request, BodyHandlers.ofString())
//   JS:      await fetch(url)   <- returns a Promise, so we use async/await
//
// A Promise means "the answer isn't here yet, I'll hand it over later".
// `await` pauses THIS function (not the whole page) until the answer arrives.

const API_KEY = 'DEMO_KEY';   // NASA's free demo key (rate-limited). Get your own at api.nasa.gov

const isoDay = (d) => d.toISOString().slice(0, 10);   // 2026-01-31

// Asks NASA DONKI for solar flares in the last N days.
// Returns { source: 'where the data came from', flares: [...] }
export async function getSolarActivity(days = 7) {
  const end = new Date();
  const start = new Date(end.getTime() - days * 86400000);
  const url = `https://api.nasa.gov/DONKI/FLR?startDate=${isoDay(start)}&endDate=${isoDay(end)}&api_key=${API_KEY}`;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('HTTP ' + response.status);   // 429 = DEMO_KEY rate limit
    const text = await response.text();
    const flares = text ? JSON.parse(text) : [];                    // DONKI sends an empty body when quiet
    return { source: 'NASA DONKI (live)', flares };
  } catch (err) {
    // No internet, rate-limited, blocked... never let the game crash: use local sample data.
    console.warn('Live API failed, using sample data:', err.message);
    const fallback = await fetch('data/sample-donki.json');
    return { source: 'sample data (offline)', flares: await fallback.json() };
  }
}

// Turns raw data into a game number between 0 and 1.
// DONKI flare classes: A, B, C (small) < M (medium) < X (large). Count the M/X ones.
export function stormRisk(flares) {
  const strong = flares.filter((f) => /^[MX]/.test(f.classType || ''));
  return Math.min(1, strong.length / 3);
}
