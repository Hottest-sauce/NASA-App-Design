// STATE: the game's numbers live here, separate from drawing code.
// (Like a plain data class in Java, or a dict in Python.)
export const resources = {
  o2:    { name: 'O₂',        value: 78,  max: 100, icon: '🫁' },
  heat:  { name: 'Heat',      value: 64,  max: 100, icon: '🌡️' },
  power: { name: 'Power',     value: 55,  max: 100, icon: '⚡' },
  food:  { name: 'Rations',   value: 40,  max: 100, icon: '🥫' },
  queue: { name: 'Queued MB', value: 120, max: 500, icon: '💾' },
  sent:  { name: 'Sent MB',   value: 0,   max: 500, icon: '📡' },
};

// Tiny "observer" pattern: other files say "tell me when state changes".
const listeners = [];
export const subscribe = (fn) => listeners.push(fn);

// effects looks like {power: 25, o2: -6}. Values are added, then clamped to 0..max.
export function applyEffects(effects = {}) {
  for (const [key, delta] of Object.entries(effects)) {
    const r = resources[key];
    r.value = Math.max(0, Math.min(r.max, r.value + delta));
  }
  listeners.forEach((fn) => fn());   // e.g. redraw the HUD
}
