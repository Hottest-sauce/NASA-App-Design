// ACTION REGISTRY: maps the "action" text in rooms.json to a function.
// (Python: a dict of functions. Java: Map<String, Consumer<Hotspot>>.)
// To add a new kind of interactable: write a function, add one line to `actions`. No other file changes.
import { openModal, closeModal, toast } from './ui.js';
import { applyEffects } from './state.js';
import * as solar from './games/solar.js';
import * as datalink from './games/datalink.js';

function simpleModal(h) {
  const panel = openModal(`
    <h2>${h.title}</h2><p>${h.text || ''}</p>
    <p class="stat">Effects: ${JSON.stringify(h.effects || {})}</p>
    <div class="row"><button id="go">Do it</button><button id="x">Close</button></div>`);
  panel.querySelector('#x').onclick = closeModal;
  panel.querySelector('#go').onclick = () => { applyEffects(h.effects); toast(h.title + ' done'); closeModal(); };
}

export const actions = {
  'modal': simpleModal,
  'minigame:solar': (h) => solar.start(h),
  'minigame:datalink': (h) => datalink.start(h),
};

export function runAction(hotspot) {
  const fn = actions[hotspot.action];
  if (!fn) { toast(`No action named "${hotspot.action}" in actions.js`); return; }
  fn(hotspot);
}
